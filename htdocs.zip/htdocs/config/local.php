<?php

declare(strict_types=1);

return [
    'db' => [
        'dsn' => 'mysql:host=sql113.infinityfree.com;port=3306;dbname=if0_41785266_iotaux;charset=utf8mb4',
        'user' => 'if0_41785266',
        'pass' => 'V7dLpmQ7lq99Ay',
    ],
];
